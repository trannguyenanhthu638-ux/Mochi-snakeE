
/* MOCHI SNAKE DELUXE v2.0 */
const screens = {
  home: document.getElementById('homeScreen'),
  how: document.getElementById('howScreen'),
  level: document.getElementById('levelScreen'),
  leaderboard: document.getElementById('leaderboardScreen'),
  achievements: document.getElementById('achievementsScreen'),
  closet: document.getElementById('closetScreen'),
  game: document.getElementById('gameScreen')
};

const SAVE_KEY = 'mochiDeluxeSave';
const defaultSave = {
  bestScore: 0, leaderboard: [], totalPoints: 0, totalFruit: 0,
  goldenFruitEaten: 0, totalPlaySeconds: 0, achievements: {},
  unlocked: { default: true }, equipped: 'default', sound: true
};
function loadSave() {
  try {
    const stored = JSON.parse(localStorage.getItem(SAVE_KEY) || 'null');
    if (stored && typeof stored === 'object') {
      return {...defaultSave, ...stored, achievements:{...defaultSave.achievements,...stored.achievements},
        unlocked:{...defaultSave.unlocked,...stored.unlocked}};
    }
    // Nhập lại kỷ lục và bảng xếp hạng từ bản Mochi Snake cũ.
    let oldBoard=[];
    try { oldBoard=JSON.parse(localStorage.getItem('mochiLeaderboard')||'[]'); } catch(e) {}
    return {...defaultSave, bestScore:Number(localStorage.getItem('mochiBestScore')||0),
      leaderboard:Array.isArray(oldBoard)?oldBoard.slice(0,5):[],
      unlocked:{...defaultSave.unlocked}};
  } catch(e) { return {...defaultSave, unlocked:{...defaultSave.unlocked}}; }
}
let saveData = loadSave();
function persist() {
  localStorage.setItem(SAVE_KEY, JSON.stringify(saveData));
  // Giữ tương thích với các phiên bản Mochi Snake trước.
  localStorage.setItem('mochiBestScore', String(saveData.bestScore));
  localStorage.setItem('mochiLeaderboard', JSON.stringify(saveData.leaderboard));
}
function showScreen(name) {
  const target = screens[name] ? name : 'home';
  if (target !== 'game') {
    stopGame(); isPaused = false; hasStarted = false; touchStart = null;
    const toast = document.getElementById('toast');
    if (toast) toast.classList.remove('show');
    clearTimeout(showToast.timer);
    const pauseButton = document.getElementById('pauseButton');
    if (pauseButton) pauseButton.textContent = '⏸ Tạm dừng';
  }
  Object.values(screens).forEach(screen => screen.classList.remove('active'));
  screens[target].classList.add('active');
  window.scrollTo({top:0,behavior:'smooth'});
  if(target==='leaderboard') renderLeaderboard();
  if(target==='achievements') renderAchievements();
  if(target==='closet') renderCloset();
}
document.querySelectorAll('[data-go]').forEach(b=>b.addEventListener('click',()=>showScreen(b.dataset.go)));
document.querySelectorAll('[data-screen-link]').forEach(b=>b.addEventListener('click',e=>{e.preventDefault();showScreen(b.dataset.screenLink)}));

const levelNames={1:'Sweet Garden',2:'Peach Paradise',3:'Berry Challenge'};
const levelSpeeds={1:170,2:125,3:90};
const levelTargets={1:100,2:150,3:200};
const levelThemes={
  1:{bg:'#fffaf5',grid:'#f1e9df',snake:'#9bc9a5',head:'#6f9f7c',fruit:'🍓'},
  2:{bg:'#fff4ec',grid:'#f6dfd1',snake:'#f0b99c',head:'#d98f70',fruit:'🍑'},
  3:{bg:'#f8f3ff',grid:'#e9def7',snake:'#b8a3d9',head:'#8f75b8',fruit:'🫐'}
};
let currentLevel=1;
document.querySelectorAll('[data-level]').forEach(b=>b.addEventListener('click',()=>{
  currentLevel=Number(b.dataset.level);
  document.getElementById('gameLevelName').textContent=levelNames[currentLevel];
  startGame();showScreen('game');
}));
function escapeHTML(v){return String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));}
function renderLeaderboard(){
  const box=document.getElementById('leaderboardRows');
  const scores=[...saveData.leaderboard].sort((a,b)=>b.score-a.score).slice(0,5);
  box.innerHTML=scores.length?scores.map((x,i)=>`<div class="leader-row"><span class="rank">${['🥇','🥈','🥉','4','5'][i]}</span><span>${escapeHTML(x.name||'Mochi Player')}</span><strong>${Number(x.score)||0}</strong></div>`).join(''):'<p class="empty-state">🌷 Chưa có thành tích nào. Hãy chơi một lượt nhé!</p>';
}
function showToast(message){
  const t=document.getElementById('toast');if(!t)return;
  t.textContent=message;t.classList.add('show');clearTimeout(showToast.timer);
  showToast.timer=setTimeout(()=>t.classList.remove('show'),2400);
}
let soundEnabled=saveData.sound, audioContext=null;
function playTone(freq=660,duration=.09,type='sine'){
  if(!soundEnabled)return;
  try{
    audioContext=audioContext||new(window.AudioContext||window.webkitAudioContext)();
    const o=audioContext.createOscillator(),g=audioContext.createGain();
    o.type=type;o.frequency.value=freq;g.gain.setValueAtTime(.055,audioContext.currentTime);
    g.gain.exponentialRampToValueAtTime(.001,audioContext.currentTime+duration);
    o.connect(g);g.connect(audioContext.destination);o.start();o.stop(audioContext.currentTime+duration);
  }catch(e){}
}
const soundButtons=[document.getElementById('soundButton'),document.getElementById('gameSoundButton')].filter(Boolean);
function updateSoundButtons(){soundButtons.forEach(b=>{b.textContent=soundEnabled?'♫ Âm thanh':'♪̸ Đã tắt';});}
soundButtons.forEach(b=>b.addEventListener('click',()=>{
  soundEnabled=!soundEnabled;saveData.sound=soundEnabled;persist();updateSoundButtons();
  showToast(soundEnabled?'Đã bật âm thanh':'Đã tắt âm thanh');
}));
updateSoundButtons();

const canvas=document.getElementById('gameCanvas'),ctx=canvas.getContext('2d');
const cell=20,columns=canvas.width/cell,rows=canvas.height/cell;
let snake=[],fruit={x:10,y:10},goldenFruit=null,goldenExpiry=0,direction={x:1,y:0},nextDirection={x:1,y:0};
let score=0,gameTimer=null,isPaused=false,isGameOver=false,hasStarted=false,isVictory=false;
let runFruit=0,runGolden=0,runStart=0,elapsedRun=0;
function stopGame(){if(gameTimer!==null){clearInterval(gameTimer);gameTimer=null;}}
function randomFreeCell(){
  let p,tries=0;
  do{p={x:Math.floor(Math.random()*columns),y:Math.floor(Math.random()*rows)};tries++;}
  while(tries<1000&&(snake.some(s=>s.x===p.x&&s.y===p.y)||(fruit&&p.x===fruit.x&&p.y===fruit.y)||(goldenFruit&&p.x===goldenFruit.x&&p.y===goldenFruit.y)));
  return p;
}
function placeFruit(){fruit=randomFreeCell();}
function spawnGolden(){
  if(goldenFruit||Math.random()>.2)return;
  goldenFruit=randomFreeCell();goldenExpiry=Date.now()+8000;
  showToast('✨ Golden Fruit xuất hiện! Ăn trong 8 giây nhé!');
  playTone(980,.18,'sine');
}
function syncScores(){
  document.getElementById('scoreValue').textContent=String(score);
  document.getElementById('scoreValueInline').textContent=String(score);
  document.getElementById('bestValue').textContent=String(saveData.bestScore);
  document.getElementById('bestValueInline').textContent=String(saveData.bestScore);
}
function startGame(){
  stopGame();snake=[{x:7,y:10},{x:6,y:10},{x:5,y:10}];
  direction={x:1,y:0};nextDirection={x:1,y:0};score=0;
  goldenFruit=null;goldenExpiry=0;runFruit=0;runGolden=0;elapsedRun=0;runStart=0;
  isPaused=false;isGameOver=false;hasStarted=false;isVictory=false;
  syncScores();
  document.getElementById('targetValue').textContent=String(levelTargets[currentLevel]);
  document.getElementById('pauseButton').textContent='⏸ Tạm dừng';
  document.getElementById('gameMessage').textContent='🐍 Mochi đã sẵn sàng! Dùng phím hoặc vuốt để bắt đầu.';
  applyTheme();placeFruit();drawGame();
}
function applyTheme(){
  const theme=levelThemes[currentLevel];
  canvas.style.borderColor=currentLevel===1?'#fffdfb':currentLevel===2?'#fff0e7':'#f0e9fb';
  document.querySelector('.game-panel').style.background=theme.bg;
}
function drawAccessory(x,y){
  const item=saveData.equipped;
  ctx.textAlign='center';ctx.textBaseline='middle';ctx.font='18px Arial';
  if(item==='bow')ctx.fillText('🎀',x,y-9);
  if(item==='crown')ctx.fillText('👑',x,y-10);
  if(item==='strawberry')ctx.fillText('🍓',x,y-10);
  if(item==='halo')ctx.fillText('😇',x,y-10);
  if(item==='glasses')ctx.fillText('🕶️',x,y+1);
}
function drawGame(){
  const theme=levelThemes[currentLevel];
  ctx.clearRect(0,0,canvas.width,canvas.height);ctx.fillStyle=theme.bg;ctx.fillRect(0,0,canvas.width,canvas.height);
  ctx.strokeStyle=theme.grid;ctx.lineWidth=1;
  for(let x=0;x<=canvas.width;x+=cell){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,canvas.height);ctx.stroke();}
  for(let y=0;y<=canvas.height;y+=cell){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(canvas.width,y);ctx.stroke();}
  ctx.font='18px Arial';ctx.textAlign='center';ctx.textBaseline='middle';
  ctx.fillText(theme.fruit,fruit.x*cell+cell/2,fruit.y*cell+cell/2+1);
  if(goldenFruit&&Date.now()<goldenExpiry){
    ctx.save();ctx.shadowColor='#f5bd43';ctx.shadowBlur=18;ctx.font='21px Arial';
    ctx.fillText('🌟',goldenFruit.x*cell+cell/2,goldenFruit.y*cell+cell/2);ctx.restore();
    const seconds=Math.max(0,Math.ceil((goldenExpiry-Date.now())/1000));
    ctx.fillStyle='#b47a2d';ctx.font='bold 11px Nunito,Arial';ctx.fillText(`${seconds}s`,goldenFruit.x*cell+cell/2,goldenFruit.y*cell-5);
  }
  snake.forEach((p,i)=>{
    ctx.fillStyle=i===0?theme.head:theme.snake;ctx.beginPath();ctx.roundRect(p.x*cell+2,p.y*cell+2,cell-4,cell-4,7);ctx.fill();
    if(i===0){
      ctx.fillStyle='#344b3b';ctx.beginPath();ctx.arc(p.x*cell+7,p.y*cell+7,2,0,Math.PI*2);ctx.arc(p.x*cell+14,p.y*cell+7,2,0,Math.PI*2);ctx.fill();
      drawAccessory(p.x*cell+cell/2,p.y*cell);
    }
  });
  if(isPaused||isGameOver){
    ctx.fillStyle='rgba(255,248,242,.82)';ctx.fillRect(0,0,canvas.width,canvas.height);
    ctx.fillStyle='#648b70';ctx.font='bold 28px Nunito,Arial';
    ctx.fillText(isVictory?'You Win!':isGameOver?'Game Over!':'Tạm dừng',canvas.width/2,canvas.height/2);
  }
}
function beginMoving(){
  if(hasStarted||isGameOver)return;hasStarted=true;runStart=Date.now();
  document.getElementById('gameMessage').textContent='🍀 Cố lên Mochi!';
  gameTimer=setInterval(gameStep,levelSpeeds[currentLevel]);
}
function changeDirection(x,y){if(x===-direction.x&&y===-direction.y)return;nextDirection={x,y};beginMoving();}
function gameStep(){
  if(isPaused||isGameOver)return;
  if(goldenFruit&&Date.now()>=goldenExpiry){goldenFruit=null;showToast('Golden Fruit đã biến mất mất rồi!');}
  direction=nextDirection;
  const head={x:snake[0].x+direction.x,y:snake[0].y+direction.y};
  const hitWall=head.x<0||head.x>=columns||head.y<0||head.y>=rows;
  const eating=head.x===fruit.x&&head.y===fruit.y;
  const eatingGolden=!!goldenFruit&&head.x===goldenFruit.x&&head.y===goldenFruit.y;
  const bodyCheck=(eating||eatingGolden)?snake:snake.slice(0,-1);
  if(hitWall||bodyCheck.some(p=>p.x===head.x&&p.y===head.y)){finishGame(false);return;}
  snake.unshift(head);
  if(eating||eatingGolden){
    if(eating){score+=10;runFruit++;saveData.totalFruit++;playTone(820,.1,'triangle');}
    if(eatingGolden){score+=50;runGolden++;saveData.goldenFruitEaten++;goldenFruit=null;goldenExpiry=0;playTone(1150,.2,'sine');showToast('✨ +50 điểm! Golden Fruit tuyệt vời!');}
    syncScores();
    if(eating){if(runFruit%5===0)spawnGolden();placeFruit();}
    checkAchievements();
    if(score>=levelTargets[currentLevel]){finishGame(true);return;}
  }else snake.pop();
  if(hasStarted)elapsedRun=Math.floor((Date.now()-runStart)/1000);
  drawGame();
}
const achievementDefs=[
  {id:'firstBite',icon:'🌱',name:'First Bite',desc:'Ăn trái cây đầu tiên.'},
  {id:'fruitLover',icon:'🍓',name:'Fruit Lover',desc:'Ăn tổng cộng 20 trái cây thường.',test:()=>saveData.totalFruit>=20},
  {id:'goldenHunter',icon:'✨',name:'Golden Hunter',desc:'Ăn được một Golden Fruit.',test:()=>saveData.goldenFruitEaten>=1},
  {id:'scoreMaster',icon:'⭐',name:'Score Master',desc:'Đạt 100 điểm trong một lượt.',test:()=>score>=100},
  {id:'gardenLegend',icon:'👑',name:'Garden Legend',desc:'Đạt 300 điểm trong một lượt.',test:()=>score>=300},
  {id:'survivor',icon:'⏳',name:'Survivor',desc:'Sống sót ít nhất 2 phút trong một lượt.',test:()=>elapsedRun>=120}
];
function award(id){
  if(saveData.achievements[id])return;
  saveData.achievements[id]=true;persist();
  const item=achievementDefs.find(a=>a.id===id);if(item)showToast(`${item.icon} Mở khóa huy hiệu ${item.name}!`);
}
function checkAchievements(){
  if(runFruit>=1)award('firstBite');
  achievementDefs.forEach(a=>{if(a.test&&a.test())award(a.id);});
}
function renderAchievements(){
  const grid=document.getElementById('achievementGrid');
  grid.innerHTML=achievementDefs.map(a=>`<article class="achievement-card ${saveData.achievements[a.id]?'earned':'locked'}"><span>${a.icon}</span><div><strong>${a.name}</strong><p>${a.desc}</p><small>${saveData.achievements[a.id]?'✓ ĐÃ MỞ KHÓA':'🔒 CHƯA ĐẠT'}</small></div></article>`).join('');
}
const outfits=[
  {id:'default',icon:'🐍',name:'Mochi nguyên bản',cost:0,desc:'Diện mạo ban đầu.'},
  {id:'bow',icon:'🎀',name:'Nơ Hồng',cost:50,need:'firstBite',needText:'Huy hiệu First Bite'},
  {id:'crown',icon:'👑',name:'Vương miện',cost:150,need:'scoreMaster',needText:'Huy hiệu Score Master'},
  {id:'strawberry',icon:'🍓',name:'Mũ Dâu',cost:100,need:'fruitLover',needText:'Huy hiệu Fruit Lover'},
  {id:'halo',icon:'😇',name:'Halo',cost:100,need:'goldenHunter',needText:'Huy hiệu Golden Hunter'},
  {id:'glasses',icon:'🕶️',name:'Kính Cool',cost:250,need:'survivor',needText:'Huy hiệu Survivor'}
];
function renderCloset(){
  document.getElementById('totalPoints').textContent=String(saveData.totalPoints);
  document.getElementById('closetGrid').innerHTML=outfits.map(o=>{
    const owned=!!saveData.unlocked[o.id],equipped=saveData.equipped===o.id;
    const canBuy=saveData.totalPoints>=o.cost&&(!o.need||saveData.achievements[o.need]);
    const status=equipped?'ĐANG MẶC':owned?'ĐÃ MỞ KHÓA':canBuy?'MỞ KHÓA NGAY':`Cần ${o.cost} điểm${o.need?' + '+o.needText:''}`;
    return `<article class="outfit-card"><span class="outfit-icon">${o.icon}</span><strong>${o.name}</strong><small>${o.desc||'Phụ kiện đáng yêu cho Mochi.'}</small><button class="outfit-action" data-outfit="${o.id}" ${(!owned&&!canBuy)||equipped?'disabled':''}>${status}</button></article>`;
  }).join('');
  document.querySelectorAll('[data-outfit]').forEach(b=>b.addEventListener('click',()=>{
    const item=outfits.find(o=>o.id===b.dataset.outfit);if(!item)return;
    if(!saveData.unlocked[item.id]){
      if(saveData.totalPoints<item.cost|| (item.need&&!saveData.achievements[item.need]))return;
      saveData.unlocked[item.id]=true;showToast(`🎉 Đã mở khóa ${item.name}!`);
    }
    saveData.equipped=item.id;persist();renderCloset();
  }));
}
function finishGame(won){
  if(isGameOver)return;
  isGameOver=true;isVictory=won;stopGame();
  if(hasStarted)elapsedRun=Math.floor((Date.now()-runStart)/1000);
  saveData.totalPlaySeconds+=elapsedRun;
  checkAchievements();
  saveData.bestScore=Math.max(saveData.bestScore,score);
  saveData.totalPoints+=score;
  if(score>0){
    const name=(prompt('Chúc mừng! Nhập tên để lưu bảng xếp hạng nhé:','Mochi Player')||'Mochi Player').trim().slice(0,18)||'Mochi Player';
    saveData.leaderboard.push({name,score,level:levelNames[currentLevel],date:new Date().toLocaleDateString('vi-VN')});
    saveData.leaderboard.sort((a,b)=>b.score-a.score);
    saveData.leaderboard=saveData.leaderboard.slice(0,5);
  }
  persist();syncScores();drawGame();
  document.getElementById('gameMessage').textContent=won?
    `🎉 Tuyệt vời! Mochi đã hoàn thành ${levelNames[currentLevel]} với ${score} điểm!`:
    `💗 Trò chơi kết thúc! Bạn đạt ${score} điểm. Nhấn Chơi lại để thử lần nữa nhé!`;
  if(won)playTone(1040,.35,'sine');else playTone(220,.22,'triangle');
}
function togglePause(){
  if(isGameOver)return;if(!hasStarted){showToast('Di chuyển Mochi trước nhé!');return;}
  isPaused=!isPaused;document.getElementById('pauseButton').textContent=isPaused?'▶ Tiếp tục':'⏸ Tạm dừng';
  document.getElementById('gameMessage').textContent=isPaused?'⏸ Mochi đang nghỉ ngơi.':'🍀 Tiếp tục thôi!';
  if(!isPaused)runStart=Date.now()-elapsedRun*1000;
  drawGame();
}
document.getElementById('pauseButton').addEventListener('click',togglePause);
document.getElementById('restartButton').addEventListener('click',startGame);
document.addEventListener('keydown',e=>{
  const keys=['ArrowUp','ArrowDown','ArrowLeft','ArrowRight',' ','w','a','s','d','W','A','S','D'];
  if(keys.includes(e.key)&&screens.game.classList.contains('active'))e.preventDefault();
  if(!screens.game.classList.contains('active'))return;
  switch(e.key){
    case'ArrowUp':case'w':case'W':changeDirection(0,-1);break;
    case'ArrowDown':case's':case'S':changeDirection(0,1);break;
    case'ArrowLeft':case'a':case'A':changeDirection(-1,0);break;
    case'ArrowRight':case'd':case'D':changeDirection(1,0);break;
    case' ':togglePause();break;
  }
});
document.querySelectorAll('[data-dir]').forEach(b=>b.addEventListener('click',()=>{
  const d={up:[0,-1],down:[0,1],left:[-1,0],right:[1,0]};changeDirection(...d[b.dataset.dir]);
}));
let touchStart=null;
canvas.addEventListener('touchstart',e=>{const t=e.changedTouches[0];touchStart={x:t.clientX,y:t.clientY};},{passive:true});
canvas.addEventListener('touchend',e=>{
  if(!touchStart)return;const t=e.changedTouches[0],dx=t.clientX-touchStart.x,dy=t.clientY-touchStart.y;
  if(Math.max(Math.abs(dx),Math.abs(dy))>18){if(Math.abs(dx)>Math.abs(dy))changeDirection(dx>0?1:-1,0);else changeDirection(0,dy>0?1:-1);}
  touchStart=null;
},{passive:true});
persist();showScreen('home');
