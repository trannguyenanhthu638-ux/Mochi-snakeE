const screens = {
  home: document.getElementById('homeScreen'),
  how: document.getElementById('howScreen'),
  level: document.getElementById('levelScreen'),
  leaderboard: document.getElementById('leaderboardScreen'),
  game: document.getElementById('gameScreen')
};

function showScreen(name) {
  Object.values(screens).forEach(screen => screen.classList.remove('active'));
  (screens[name] || screens.home).classList.add('active');
  window.scrollTo({ top: 0, behavior: 'smooth' });
  if (name === 'leaderboard') renderLeaderboard();
  if (name !== 'game') stopGame();
}

document.querySelectorAll('[data-go]').forEach(button => {
  button.addEventListener('click', () => showScreen(button.dataset.go));
});
document.querySelectorAll('[data-screen-link]').forEach(link => {
  link.addEventListener('click', event => {
    event.preventDefault();
    showScreen(link.dataset.screenLink);
  });
});

const levelNames = { 1: 'Sweet Garden', 2: 'Peach Paradise', 3: 'Berry Challenge' };
const levelSpeeds = { 1: 170, 2: 125, 3: 90 };

document.querySelectorAll('[data-level]').forEach(button => {
  button.addEventListener('click', () => {
    currentLevel = Number(button.dataset.level);
    document.getElementById('gameLevelName').textContent = levelNames[currentLevel];
    startGame();
    showScreen('game');
  });
});

function renderLeaderboard() {
  const container = document.getElementById('leaderboardRows');
  let scores = [];
  try { scores = JSON.parse(localStorage.getItem('mochiLeaderboard') || '[]'); } catch (error) { scores = []; }
  scores.sort((a, b) => b.score - a.score);
  scores = scores.slice(0, 5);
  if (!scores.length) {
    container.innerHTML = '<p class="empty-state">🌷 Chưa có thành tích nào. Hãy chơi một lượt nhé!</p>';
    return;
  }
  container.innerHTML = scores.map((item, index) =>
    `<div class="leader-row"><span class="rank">#${index + 1}</span><span>${escapeHTML(item.name || 'Mochi Player')}</span><strong>${Number(item.score) || 0}</strong></div>`
  ).join('');
}

function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, char => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;'
  })[char]);
}

function showToast(message) {
  const toast = document.getElementById('toast');
  toast.textContent = message;
  toast.classList.add('show');
  window.clearTimeout(showToast.timer);
  showToast.timer = window.setTimeout(() => toast.classList.remove('show'), 2600);
}

let soundEnabled = true;
document.getElementById('soundButton').addEventListener('click', event => {
  soundEnabled = !soundEnabled;
  event.currentTarget.textContent = soundEnabled ? '♫' : '♪̸';
  event.currentTarget.setAttribute('aria-label', soundEnabled ? 'Tắt âm thanh' : 'Bật âm thanh');
  showToast(soundEnabled ? 'Âm thanh đã bật' : 'Âm thanh đã tắt');
});

// ===== PHẦN TRÒ CHƠI MOCHI SNAKE =====
const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
const cell = 20;
const columns = canvas.width / cell;
const rows = canvas.height / cell;

let snake = [];
let fruit = { x: 10, y: 10 };
let direction = { x: 1, y: 0 };
let nextDirection = { x: 1, y: 0 };
let score = 0;
let currentLevel = 1;
let gameTimer = null;
let isPaused = false;
let isGameOver = false;
let hasStarted = false;

function startGame() {
  stopGame();
  snake = [{ x: 7, y: 10 }, { x: 6, y: 10 }, { x: 5, y: 10 }];
  direction = { x: 1, y: 0 };
  nextDirection = { x: 1, y: 0 };
  score = 0;
  isPaused = false;
  isGameOver = false;
  hasStarted = false;
  document.getElementById('scoreValue').textContent = '0';
  document.getElementById('bestValue').textContent = localStorage.getItem('mochiBestScore') || '0';
  document.getElementById('pauseButton').textContent = '⏸ Tạm dừng';
  document.getElementById('gameMessage').textContent = '🐍 Mochi đã sẵn sàng! Dùng phím mũi tên để bắt đầu.';
  placeFruit();
  drawGame();
}

function stopGame() {
  if (gameTimer) {
    clearInterval(gameTimer);
    gameTimer = null;
  }
}

function placeFruit() {
  do {
    fruit = { x: Math.floor(Math.random() * columns), y: Math.floor(Math.random() * rows) };
  } while (snake.some(part => part.x === fruit.x && part.y === fruit.y));
}

function drawGame() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = '#fffaf5';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // Kẻ ô nền nhẹ cho khu vườn.
  ctx.strokeStyle = '#f1e9df';
  ctx.lineWidth = 1;
  for (let x = 0; x <= canvas.width; x += cell) {
    ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, canvas.height); ctx.stroke();
  }
  for (let y = 0; y <= canvas.height; y += cell) {
    ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(canvas.width, y); ctx.stroke();
  }

  // Vẽ trái cây.
  ctx.font = '18px Arial';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('🍓', fruit.x * cell + cell / 2, fruit.y * cell + cell / 2 + 1);

  // Vẽ thân và đầu rắn.
  snake.forEach((part, index) => {
    ctx.fillStyle = index === 0 ? '#6f9f7c' : '#9bc9a5';
    ctx.beginPath();
    ctx.roundRect(part.x * cell + 2, part.y * cell + 2, cell - 4, cell - 4, 7);
    ctx.fill();
    if (index === 0) {
      ctx.fillStyle = '#344b3b';
      ctx.beginPath();
      ctx.arc(part.x * cell + 7, part.y * cell + 7, 2, 0, Math.PI * 2);
      ctx.arc(part.x * cell + 14, part.y * cell + 7, 2, 0, Math.PI * 2);
      ctx.fill();
    }
  });

  if (isPaused || isGameOver) {
    ctx.fillStyle = 'rgba(255, 248, 242, 0.78)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = '#648b70';
    ctx.font = 'bold 27px Nunito, Arial';
    ctx.fillText(isGameOver ? 'Game Over!' : 'Tạm dừng', canvas.width / 2, canvas.height / 2);
  }
}

function gameStep() {
  if (isPaused || isGameOver) return;
  direction = nextDirection;
  const head = { x: snake[0].x + direction.x, y: snake[0].y + direction.y };

  const hitWall = head.x < 0 || head.x >= columns || head.y < 0 || head.y >= rows;
  const hitBody = snake.some((part, index) =>
    index !== snake.length - 1 && part.x === head.x && part.y === head.y
  );

  if (hitWall || hitBody) {
    endGame();
    return;
  }

  snake.unshift(head);
  if (head.x === fruit.x && head.y === fruit.y) {
    score += 10;
    document.getElementById('scoreValue').textContent = String(score);
    placeFruit();
  } else {
    snake.pop();
  }
  drawGame();
}

function beginMoving() {
  if (hasStarted || isGameOver) return;
  hasStarted = true;
  document.getElementById('gameMessage').textContent = '🍀 Cố lên Mochi!';
  gameTimer = setInterval(gameStep, levelSpeeds[currentLevel]);
}

function endGame() {
  isGameOver = true;
  stopGame();
  drawGame();
  document.getElementById('gameMessage').textContent = `💗 Trò chơi kết thúc! Bạn đạt ${score} điểm. Nhấn Chơi lại để thử lần nữa nhé!`;

  const best = Number(localStorage.getItem('mochiBestScore') || 0);
  if (score > best) localStorage.setItem('mochiBestScore', String(score));
  document.getElementById('bestValue').textContent = String(Math.max(best, score));

  if (score > 0) {
    let scores = [];
    try { scores = JSON.parse(localStorage.getItem('mochiLeaderboard') || '[]'); } catch (error) {}
    scores.push({ name: 'Mochi Player', score });
    scores.sort((a, b) => b.score - a.score);
    localStorage.setItem('mochiLeaderboard', JSON.stringify(scores.slice(0, 10)));
  }
}

function changeDirection(x, y) {
  if (x === -direction.x && y === -direction.y) return;
  nextDirection = { x, y };
  beginMoving();
}

document.addEventListener('keydown', event => {
  const keys = ['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', ' ', 'w', 'a', 's', 'd', 'W', 'A', 'S', 'D'];
  if (keys.includes(event.key)) event.preventDefault();
  if (!screens.game.classList.contains('active')) return;

  switch (event.key) {
    case 'ArrowUp': case 'w': case 'W': changeDirection(0, -1); break;
    case 'ArrowDown': case 's': case 'S': changeDirection(0, 1); break;
    case 'ArrowLeft': case 'a': case 'A': changeDirection(-1, 0); break;
    case 'ArrowRight': case 'd': case 'D': changeDirection(1, 0); break;
    case ' ': togglePause(); break;
  }
});

function togglePause() {
  if (isGameOver) return;
  if (!hasStarted) {
    showToast('Hãy di chuyển Mochi trước nhé!');
    return;
  }
  isPaused = !isPaused;
  document.getElementById('pauseButton').textContent = isPaused ? '▶ Tiếp tục' : '⏸ Tạm dừng';
  document.getElementById('gameMessage').textContent = isPaused ? '⏸ Mochi đang nghỉ ngơi.' : '🍀 Tiếp tục thôi!';
  drawGame();
}

document.getElementById('pauseButton').addEventListener('click', togglePause);
document.getElementById('restartButton').addEventListener('click', startGame);

// Khởi tạo giao diện ở màn hình trang chủ.
showScreen('home');
