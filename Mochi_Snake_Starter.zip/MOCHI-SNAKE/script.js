const screens = {
  home: document.getElementById('homeScreen'),
  how: document.getElementById('howScreen'),
  level: document.getElementById('levelScreen'),
  leaderboard: document.getElementById('leaderboardScreen'),
  game: document.getElementById('gameScreen')
};

function showScreen(name) {
  Object.values(screens).forEach(screen => screen.classList.remove('active'));
  (screens[name] || screens.home).classList.add('active');
  window.scrollTo({ top: 0, behavior: 'smooth' });
  if (name === 'leaderboard') renderLeaderboard();
}

document.querySelectorAll('[data-go]').forEach(button => {
  button.addEventListener('click', () => showScreen(button.dataset.go));
});
document.querySelectorAll('[data-screen-link]').forEach(link => {
  link.addEventListener('click', event => {
    event.preventDefault();
    showScreen(link.dataset.screenLink);
  });
});

const levelNames = {
  1: 'Sweet Garden',
  2: 'Peach Paradise',
  3: 'Berry Challenge'
};

document.querySelectorAll('[data-level]').forEach(button => {
  button.addEventListener('click', () => {
    const level = Number(button.dataset.level);
    document.getElementById('gameLevelName').textContent = levelNames[level];
    document.getElementById('scoreValue').textContent = '0';
    document.getElementById('bestValue').textContent = localStorage.getItem('mochiBestScore') || '0';
    showScreen('game');
    showToast('🌷 Màn chơi sẽ được kích hoạt ở chặng lập trình game!');
  });
});

function renderLeaderboard() {
  const container = document.getElementById('leaderboardRows');
  let scores = [];
  try { scores = JSON.parse(localStorage.getItem('mochiLeaderboard') || '[]'); } catch (error) { scores = []; }
  scores.sort((a, b) => b.score - a.score);
  scores = scores.slice(0, 5);
  if (!scores.length) {
    container.innerHTML = '<p class="empty-state">🌷 Chưa có thành tích nào. Hãy chơi một lượt nhé!</p>';
    return;
  }
  container.innerHTML = scores.map((item, index) =>
    `<div class="leader-row"><span class="rank">#${index + 1}</span><span>${escapeHTML(item.name || 'Mochi Player')}</span><strong>${Number(item.score) || 0}</strong></div>`
  ).join('');
}

function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, char => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;'
  })[char]);
}

function showToast(message) {
  const toast = document.getElementById('toast');
  toast.textContent = message;
  toast.classList.add('show');
  window.clearTimeout(showToast.timer);
  showToast.timer = window.setTimeout(() => toast.classList.remove('show'), 2600);
}

let soundEnabled = true;
document.getElementById('soundButton').addEventListener('click', event => {
  soundEnabled = !soundEnabled;
  event.currentTarget.textContent = soundEnabled ? '♫' : '♪̸';
  event.currentTarget.setAttribute('aria-label', soundEnabled ? 'Tắt âm thanh' : 'Bật âm thanh');
  showToast(soundEnabled ? 'Âm thanh đã bật' : 'Âm thanh đã tắt');
});

// Khởi tạo giao diện ở màn hình trang chủ.
showScreen('home');
